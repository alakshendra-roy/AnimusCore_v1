#include "animus.hpp"
#include <iostream>
#include <chrono>

int main() {
    std::cout << "========================================\n";
    std::cout << "  ANIMUS Core Engine v1.0 - Latency Benchmark Harness\n";
    std::cout << "========================================\n\n";

    auto engine = animus::Engine::Create(65536);

    // Limit batch to buffer capacity for standard single-thread test, or handle overflow
    constexpr size_t TEST_BATCH = 65000;
    std::cout << "Running " << TEST_BATCH << " telemetry logging iterations...\n";

    auto start = std::chrono::high_resolution_clock::now();

    size_t ingested = 0;
    for (size_t i = 0; i < TEST_BATCH; ++i) {
        if (engine->record(101, static_cast<uint32_t>(i), static_cast<uint64_t>(i * 2))) {
            ingested++;
        }
    }

    auto end = std::chrono::high_resolution_clock::now();
    double total_ns = static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count());
    double avg_ns = ingested > 0 ? (total_ns / ingested) : 0.0;

    std::cout << "\n[RESULTS]\n";
    std::cout << " Total Events Ingested  : " << ingested << "\n";
    std::cout << " Total Time Elapsed     : " << (total_ns / 1'000'000.0) << " ms\n";
    std::cout << " Avg Execution Time     : " << avg_ns << " ns\n";
    std::cout << " Kernel Guard Status    : " << (engine->is_guard_active() ? "ACTIVE" : "DISABLED") << "\n";
    std::cout << "========================================\n";

    return 0;
}