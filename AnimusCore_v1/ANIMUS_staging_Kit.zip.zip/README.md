# ANIMUS Core Engine - Telemetry SDK

## Overview
The ANIMUS Core Engine is a lock-free, ultra-low-latency telemetry ingestion SDK for C++ environments. It is designed for high-performance systems (trading engines, game loops) that require real-time event logging without thread contention, disk I/O bottlenecks, or CPU pipeline stalling.

## Included Files
* `animus.hpp`: The core API contract and payload structures.
* `animus_engine.cpp`: The underlying lock-free ring buffer implementation.
* `AnimusCore_v1.cpp`: A fully functional benchmark harness and integration example.

## Performance Benchmarks (Hardware Validated)
* **Execution Latency:** ~10.29 nanoseconds per log operation.
* **Throughput:** ~97 Million operations per second.
* **Lock Overhead:** 0 ns (Pure lock-free, atomic L1 cache-aligned writes).

## Quick Start Integration
1. Drop `animus.hpp` into your project's include directory.
2. Compile `animus_engine.cpp` alongside your application source.
3. Instantiate the engine and log events natively:

    ```cpp
    #include "animus.hpp"

    // 1. Initialize a 64k ring buffer
    auto engine = animus::Engine::Create(65536);

    // 2. Log telemetry events non-blocking
    engine->record(EVENT_ID, TRACE_ID, METRIC_VALUE);
    ```

## Architecture Notes
This engine utilizes `alignas(64)` memory padding to prevent false sharing across CPU cores and relies on relaxed/acquire-release memory semantics to ensure thread safety without standard library mutexes.